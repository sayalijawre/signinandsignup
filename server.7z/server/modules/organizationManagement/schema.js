DefalutObj = 
    {
        isVerified: false,
        isDeleted: false,
        profile: {
            about: '',
            locations: [],
            followers: [],
            post: [ ],
            jobs: [ ]
        }

    }

module.exports = DefalutObj;